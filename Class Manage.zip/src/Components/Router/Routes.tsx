import { createBrowserRouter } from "react-router-dom";
import ForgotPassword from "../../Pages/Auth/ForgotPassword";
import Login from "../../Pages/Auth/Login";
import NewPassword from "../../Pages/Auth/NewPassword";
import OTPVerify from "../../Pages/Auth/OTPVerify";
import Dashboard from "../../Pages/Dashboard/Dashboard";
import MainLayout from "../Layout/MainLayout";
import { ErrorPage } from "../UI/ErrorPage";
import UserList from "../../Pages/UserList/UserList";
import Reports from "../../Pages/Reports/Reports";
import Setting from "../../Pages/Setting";
import AdminList from "../../Pages/AdminList/AdminList";
import TermsCondition from "../../Pages/TermsCondition";
import FAQ from "../../Pages/FAQ/FAQ";
import About from "../../Pages/About";
import PrivacyPolicy from "../../Pages/PrivacyPolicy";
import Profile from "../../Pages/Profile";

const router = createBrowserRouter([
    {
        path: "/",
        element: <MainLayout />,
        errorElement: <ErrorPage />,
        children: [
            {
                path: "",
                element: <Dashboard />
            },
            {
                path: "users-list",
                element: <UserList />
            },
            {
                path: "report",
                element: <Reports />
            },
            {
                path: "profile",
                element: <Profile />
            },
            {
                path: "setting",
                element: <Setting />
            },
            {
                path: "all-admin",
                element: <AdminList />
            },
            {
                path: "terms-condition",
                element: <TermsCondition />
            },
            {
                path: "faq",
                element: <FAQ />
            },
            {
                path: "about",
                element: <About />
            },
            {
                path: "policy",
                element: <PrivacyPolicy />
            },
        ]
    },
    {path: "/login", element: <Login />},
    {path: "/forgot-password", element: <ForgotPassword />},
    {path: "/verify-otp", element: <OTPVerify />},
    {path: "/new-password", element: <NewPassword />},
]);



export default router;