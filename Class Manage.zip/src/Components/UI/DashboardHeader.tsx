import { Avatar, Badge } from 'antd'
import { FiBell } from 'react-icons/fi'
import { Link } from 'react-router-dom'

const DashboardHeader = () => {
  return (
    <div className='px-6 h-[80px] flex items-center justify-between mb-10'>
      <h1 className='text-white text-2xl font-semibold'>Dashboard</h1>
      <div className="flex items-center gap-8">
        <Link to="/notifications">
        <Badge  showZero count={0} className='border-gray p-2'>
          <FiBell size={25} color='white'/>
        </Badge>
        </Link>
        <div className="flex items-center gap-5">
          <Link to="profile"><Avatar size={40} src="https://images.pexels.com/photos/14646100/pexels-photo-14646100.jpeg"/></Link>

          <div className="">
            <h1 className='text-lg text-white font-bold'>Mr. Jackson</h1>
            <p className='text-gray text-[15px] font-semibold'>Admin</p>
          </div>
        </div>
      </div>

    </div>
  )
}

export default DashboardHeader