import { Modal } from "antd";

const DeleteModal = ({ open, onClose, onDelete, itemName, message }: any) => {
  
  return (
    <Modal
      open={open}
      onCancel={onClose}
      footer={null}
      centered
      width={500}
      title={
        <h3 className="text-xl font-semibold text-primary">Delete Item</h3>
      }
    >
      <p className="text-gray-300 mb-6 text-lg">
        {message ?? `Are you sure you want to delete item.`}
      </p>

      <div className="flex justify-end space-x-4">
        <button
          onClick={onClose}
          className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
        >
          Cancel
        </button>
        <button
          onClick={onDelete}
          className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
        >
          Delete
        </button>
      </div>
    </Modal>
  );
};

export default DeleteModal;