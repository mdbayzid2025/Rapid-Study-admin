import { ConfigProvider, Layout } from "antd";
import React from "react";
import Sidebar from "./Sidebar";
import DashboardHeader from "../UI/DashboardHeader";
import { Outlet } from "react-router-dom";

const { Content } = Layout;

const MainLayout = () => {
  return (
    <ConfigProvider
      theme={{
        token: { colorPrimary: "#808080" },
        components: {
          Input: {
            borderRadius: 12,
            colorBorder: "#989898",
            colorText: "#757575",
            inputFontSize: 16,
            colorTextPlaceholder: "#808080", 
            colorBgContainer: "#000000"           
          },

          Modal: {
            contentBg: "#232323",
            colorIcon: "white",
            colorBgMask: "rgba(64,64,64,0.5)",
            headerBg: "transparent",
            titleColor: "#909090 ",
            titleFontSize: 22,
          },
          Select: {
            colorBgContainer: "rgba(255, 255, 255, 0.1)",
            colorBorder: "#808080",
            colorText: "#FFFFFF",
            colorBgElevated: "#808080",
            optionSelectedBg: "#121212",
            optionActiveBg: "#404040",
            // colorTextPlaceholder: "#808080", 
            colorTextPlaceholder: "#808080", 
          },
          Collapse: {
            headerBg: "#404040",
            contentBg: "#232323",
            colorText: "#909090",
            fontSize: 18,                        
          },
          Pagination: {
            itemActiveBg: "#808080",
            itemBg: "rgba(0,42,96,0.3215686274509804)",
            colorPrimary: "rgb(255,255,255)",
            colorText: "#ffffff",
            colorTextDisabled: "rgba(255,255,255,0.5)",
            borderRadius: 25,
            itemSize: 40,
          },
          Table: {
            colorBgContainer: "#232323",
            borderColor: "#989898",
            headerBg: "#404040",
            headerColor: "#ffffff",
            headerSplitColor: "transparent",
            colorText: "#ffffff",
            colorSplit: "transparent",
            cellPaddingBlock: 13,
          },
        },
      }}
    >
      <Layout style={{ height: "100vh" }}>
        <Sidebar />
        <Layout style={{ background: "#232323" }} className="">
          <DashboardHeader />
          <Content className="overflow-y-auto m-6 ">
            <Outlet />
          </Content>
        </Layout>
      </Layout>
    </ConfigProvider>
  );
};

export default MainLayout;

/*

<Search
      addonBefore="https://"
      placeholder="input search text"
      allowClear
      onSearch={onSearch}
      style={{ width: 304 }}
    />

    */
