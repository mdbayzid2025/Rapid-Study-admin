import React from "react";
import { sidebarItems } from "../../utils/sidebarItems";
import { Link, useLocation } from "react-router-dom";
import { Button, ConfigProvider, Layout, Menu } from "antd";
import { FiLogOut } from "react-icons/fi";

const { Sider } = Layout;

const Sidebar = () => {
  const location = useLocation();

  const generateSidebarItems = (items: any) => {
    return items?.map((item: any) => {
      if(item?.children){
        return {
          key: item?.key,
          icon: item?.icon,
          label: item?.label,
          children: item?.children?.map((child :any)=> ({
            key: `/${child?.path}`,
            icon: child?.icon,
            label: <Link to={`/${child?.path}`}>{child?.label}</Link>
          }))
        }
      }
      return {
        key: `/${item?.key}`,
        icon: item?.icon,
        label: <Link to={`/${item?.path}`}>{item?.label}</Link>,
      };
    });
  };

  return (
    <ConfigProvider
      theme={{
        token: { colorPrimary: "#808080" },
        components: {
          Menu: {
            // itemSelectedBg: "#1A1A1A",
            itemSelectedBg: "#121212",
            itemSelectedColor: "#ffffff",
            itemColor:"#ffffff",
            itemActiveBg: "#808080",
            itemHoverBg: "#808080",
            itemHoverColor: "#ffffff",
            itemBorderRadius: 0,
            itemHeight: 45,
            itemMarginBlock: 12,
          },
        },
      }}
    >
      <Sider width={250} theme="dark" breakpoint="md" collapsedWidth="0" className="border-r border-gray">
        <div className="bg-gray w-full h-[100px] ">

        </div>
        <div className="flex flex-col" style={{height: "calc(100vh - 100px)", backgroundColor: "#121212"}}>
        <Menu mode="inline" selectedKeys={[location?.pathname]} items={generateSidebarItems(sidebarItems)}  style={{flexGrow: 1, overflowY: "auto", backgroundColor: "#232323"}}/>

        {/* Logout Button */}
        <Button size="large" style={{borderRadius: "0", paddingLeft: 30, minHeight: 45, marginTop: "auto"}} className="!flex !justify-start" icon={<FiLogOut size={20} />}>  
        LogOut        
        </Button>
        </div>
      </Sider>
    </ConfigProvider>
  );
};

export default Sidebar;
