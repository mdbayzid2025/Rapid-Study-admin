import { Button, ConfigProvider, Form, Input } from "antd";
import { useForm } from "antd/es/form/Form";
import type { OTPProps } from "antd/es/input/OTP";
import { useNavigate } from "react-router-dom";

const OTPVerify = () => {
  const [form] = useForm();

  const navigate = useNavigate();
  const handleLogin = async (values: any) => {
    try {
      console.log("handleLogin", values);

      navigate("/new-password");
    } catch (error) {
      console.log(error);
    }
  };

  const onChange: OTPProps["onChange"] = (text) => {
    console.log("onChange:", text);
  };

  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: "#002C66",

          colorBgContainer: "#F1F4F9",
        },
        components: {
          Input: {
            borderRadius: 12,
            colorBorder: "#989898",
            colorPrimaryBg: "#121212",
            colorText: "#757575",
            inputFontSize: 16,
            activeBg: "#989898",
            colorBgBlur: "#989898",
            colorTextPlaceholder: "#808080 ",
          },
        },
      }}
    >
      <div className="flex items-center justify-center h-screen">
        <div className="border border-borderColor rounded-xl px-12 py-8 min-w-xl">
          <h1 className="text-center text-white text-3xl font-bold mb-4">
            Verify OTP
          </h1>
          <p className="text-center text-gray text-lg mb-8">
            Enter your OTP which has been sent to your email
          </p>

          <Form form={form} layout="vertical" onFinish={handleLogin}>
            {/* <div className="border border-borderColor rounded-2xl bg-black/50 py-2.5 flex justify-center"> */}
            <div className="bg-[#000000] rounded-2xl  py-2.5 flex justify-center">
              <Input.OTP
                size="large"
                variant="filled"                
                length={4}
                style={{
                  color: "white", // Set text color to whit
                }}
                separator={(i) => (
                  <span style={{ color: "white", marginInline: 10 }}>—</span>
                )}                
                className=""
                onChange={onChange}                
              />
            </div>
            <div className="text-center my-7">
            <p className="text-center text-gray text-lg mb-2">A code has been sent to your email</p>
            <span className="text-[#FF6F61] text-xl font-semibold">00:00</span>
            </div>

            <Button
              type="primary"
              size="large"
              htmlType="submit"
              style={{
                width: "100%",
                height: 50,
                borderRadius: 20,
                background: "rgba(255, 255, 255, 0.1)",
                marginTop: 20,
              }}
            >
              Verify
            </Button>
            <Button size="large" type="text" style={{color: "rgba(255, 255, 255, 0.4)", fontWeight: 500, width: "100%", marginTop: 10}}>Resend</Button>
          </Form>
        </div>
      </div>
    </ConfigProvider>
  );
};

export default OTPVerify;
