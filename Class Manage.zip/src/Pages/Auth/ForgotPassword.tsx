import { Button, ConfigProvider, Form, Input } from "antd";
import { useForm } from "antd/es/form/Form";
import FormItem from "antd/es/form/FormItem";
import { useNavigate } from "react-router-dom";

const ForgotPassword = () => {
  const [form] = useForm();
  const navigate = useNavigate()
  const handleLogin = async (values: any) => {
    try {
      console.log("handleLogin", values);
      navigate("/verify-otp")
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: "#002C66",

          colorBgContainer: "#F1F4F9",
        },
        components: {
          Input: {
            borderRadius: 12,
            colorBorder: "#989898",
            colorPrimaryBg: "#121212",
            colorText: "#757575",
            inputFontSize: 16,
            activeBg: "#989898",
            colorBgBlur: "#989898",
            colorTextPlaceholder: "#808080 ",
          },
        },
      }}
    >
      <div className="flex items-center justify-center h-screen">
        <div className="border border-borderColor rounded-xl px-12 py-8 min-w-xl">
          <h1 className="text-center text-white text-3xl font-bold mb-4">
            Verify OTP
          </h1>
          <p className="text-center text-gray text-lg mb-8">
            To reset your password, please enter your registered email address.
          </p>

          <Form form={form} layout="vertical" onFinish={handleLogin}>
            <FormItem
              name="email"
              label={<p className="text-gray font-semibold text-lg">Email</p>}
              rules={[
                {
                  required: true,
                  type: "email",
                  message: "Please enter your email",
                },
              ]}
            >
              <Input
                style={{ backgroundColor: "#00000040", height: 48 }}
                placeholder="example@gmail.com"
                autoComplete="off"
              />
            </FormItem>
            
            <Button
              type="primary"
              htmlType="submit"
              size="large"
              style={{
                width: "100%",
                height: 50,
                borderRadius: 20,
                background: "rgba(255, 255, 255, 0.1)",
                marginTop: 20
              }}
            >
              Continue
            </Button>
          </Form>
        </div>
      </div>
    </ConfigProvider>
  );
};

export default ForgotPassword;
