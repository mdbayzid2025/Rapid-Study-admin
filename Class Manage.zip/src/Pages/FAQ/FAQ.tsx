import { EditOutlined } from "@ant-design/icons";
import { Button, Space, Collapse, Tooltip } from "antd";
import { TfiTrash } from "react-icons/tfi";
import AddFAQModal from "./AddFAQModal";
import { useState } from "react";
import DeleteModal from "../../Components/UI/DeleteModal";

const { Panel } = Collapse;

const FAQ = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [open, setOpen] = useState<boolean>(false);
  const [editData, setEditData] = useState<any | null>(null);
  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false); 
  
  const handleAdd = (data: any) => {
    console.log("Added:", data);
  };

  const columns = [
    {
      title: "Question",
      dataIndex: "question",
      key: "question",
      render: (text: string) => <span>{text}?</span>,
    },
    {
      title: "Actions",
      key: "actions",
      render: (_: any, record: any) => (
        <div className="flex items-center gap-5">
          <Tooltip title="Edit">
            <EditOutlined
              size={20}
              style={{ color: "orange", cursor: "pointer" }}
              onClick={() => console.log("Edit:", record)}
            />
          </Tooltip>

          <Tooltip title="Delete">
            <TfiTrash
              size={20}
              style={{ color: "red", cursor: "pointer" }}
              onClick={() => console.log("Delete:", record)}
            />
          </Tooltip>
        </div>
      ),
    },
  ];

    const handleDelete = () => {
    // Handle your delete action here, for example:
    // console.log(`Item ${editData?.name} has been deleted.`);
    
    setDeleteModalOpen(false);
    setEditData(null)
    return;
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl text-white font-semibold">FAQ</h1>
        <Button
          onClick={() => setOpen(true)}
          type="primary"
          size="large"
          style={{
            width: 150,
            height: 50,
            borderRadius: 20,
            background: "rgba(255, 255, 255, 0.1)",
            marginTop: 20,
          }}
        >
          Add Faq
        </Button>
      </div>

      <Collapse bordered defaultActiveKey={["1"]}>
        {dataSource.map((item) => (
          <Panel          
            header={
              <div className="flex items-center justify-between text-white">
                {item?.question}
                <div className="flex items-center gap-5">
                  <Tooltip title="Edit">
                    <EditOutlined
                      size={20}
                      style={{ color: "orange", cursor: "pointer" }}
                      onClick={(e) => {e.stopPropagation(); setOpen(true); setEditData(item)}}
                    />
                  </Tooltip>

                  <Tooltip title="Delete">
                    <TfiTrash
                      size={20}
                      style={{ color: "red", cursor: "pointer" }}
                      onClick={(e) => {e.stopPropagation(); setDeleteModalOpen(true); setEditData(item)}}
                    />
                  </Tooltip>
                </div>
              </div>} key={item?.key}>
            <p className="text-justify capitalize">{item?.answer}</p>
          </Panel>
        ))}
      </Collapse>

      <AddFAQModal
        open={open}
        setOpen={setOpen}
        editData={editData}
        setEditData={setEditData}
      />

       {/* Delete Confirm Modal */}
      <DeleteModal
        open={isDeleteModalOpen}
        onClose={()=>setDeleteModalOpen(false)}
        onDelete={handleDelete}
        itemName={editData}
      />
    </div>
  );
};

export default FAQ;

const dataSource = [
  {
    key: 1,
    question: "Our Story?",
    answer:
      "convallis. Praesent felis, placerat Ut ac quis dui volutpat vitae elementum quis adipiscing malesuada tempor non ipsum non, nec vitae amet, Donec tincidunt efficitur. in In ipsum Cras turpis viverra laoreet ullamcorper placerat diam sed leo. faucibus vitae eget vitae vehicula, luctus id Lorem fringilla tempor faucibus ipsum Vestibulum tincidunt ullamcorper elit diam turpis placerat vitae Nunc vehicula, ex faucibus venenatis at, maximus commodo urna. Nam ex quis sit non vehicula, massa urna at",
  },
  {
    key: 2,
    question: "When to use Doctor For You?",
    answer:
      "convallis. Praesent felis, placerat Ut ac quis dui volutpat vitae elementum quis adipiscing malesuada tempor non ipsum non, nec vitae amet, Donec tincidunt efficitur. in In ipsum Cras turpis viverra laoreet ullamcorper placerat diam sed leo. faucibus vitae eget vitae vehicula, luctus id Lorem fringilla tempor faucibus ipsum Vestibulum tincidunt ullamcorper elit diam turpis placerat vitae Nunc vehicula, ex faucibus venenatis at, maximus commodo urna. Nam ex quis sit non vehicula, massa urna at",
  },
  {
    key: 3,
    question: "Our Mission?",
    answer:
      "convallis. Praesent felis, placerat Ut ac quis dui volutpat vitae elementum quis adipiscing malesuada tempor non ipsum non, nec vitae amet, Donec tincidunt efficitur. in In ipsum Cras turpis viverra laoreet ullamcorper placerat diam sed leo. faucibus vitae eget vitae vehicula, luctus id Lorem fringilla tempor faucibus ipsum Vestibulum tincidunt ullamcorper elit diam turpis placerat vitae Nunc vehicula, ex faucibus venenatis at, maximus commodo urna. Nam ex quis sit non vehicula, massa urna at",
  },
];
