import { Button, Form, Input, Modal, Select } from "antd";
import { useEffect } from "react";
import { MdOutlineVisibility, MdOutlineVisibilityOff } from "react-icons/md";

const { Option } = Select;

const AddAdminModal = ({
  editData,
  open,
  setOpen,  
  onSubmit,
}: any) => {
  //   const [isModalOpen, setIsModalOpen] = useState(false);
  const [form] = Form.useForm();

  console.log("editdata", editData);
  useEffect(()=>{
     if ( editData) {
      form.setFieldsValue(editData);
    }
  },[editData])

  const handleCancel = () => {
    setOpen(false);
    form.resetFields();
  };

  const handleOk = () => {
    form
      .validateFields()
      .then((values) => {
        onSubmit(values);
        setOpen(false);
        form.resetFields();
      })
      .catch((info) => {
        console.log("Validate Failed:", info);
      });
  };

  return (
    <>
      <Modal
        title={!editData  ? "Add Admin" : "Edit Admin"}
        open={open}
        onCancel={handleCancel}
        onOk={handleOk}
        okText={!editData  ? "Save" : "Update"}
        cancelText="Cancel"
        centered
        footer={false}
      >
        <Form form={form} layout="vertical">
          <Form.Item
            label={<p className="text-lg text-gray-200">Name</p>}
            name="name"
            rules={[{ required: true, message: "Please enter name" }]}
          >
            <Input
              placeholder="Enter name"
              style={{ height: 45 }}
            />
          </Form.Item>

          <Form.Item
            label={<p className="text-lg text-gray-200">Email</p>}
            name="email"
            rules={[
              { required: true, message: "Please enter email" },
              { type: "email", message: "Enter a valid email" },
            ]}
          >
            <Input
              placeholder="Enter email"
              style={{ height: 45 }}
            />
          </Form.Item>

          <Form.Item
            label={<p className="text-lg text-gray-200">Role</p>}
            name="role"
            rules={[{ required: true, message: "Please select role" }]}
          >
            <Select placeholder="Select role" style={{ height: 45, color: "white",  }}>
              <Option style={{ height: 45 }} value="superadmin">
                Super Admin
              </Option>
              <Option style={{ height: 45 }} value="admin">
                Admin
              </Option>
              <Option style={{ height: 45 }} value="moderator">
                Moderator
              </Option>
            </Select>
          </Form.Item>

         {!editData && <Form.Item
            label={<p className="text-lg text-gray-200">Password</p>}
            name="password"
            rules={[
              { required: !editData , message: "Please enter password" },
            ]}
          >
            <Input.Password
              placeholder="Enter password"
              iconRender={(visible) =>
                visible ? (
                  <MdOutlineVisibility size={20} color="#808080" cursor="pointer"/>
                ) : (
                  <MdOutlineVisibilityOff size={20} color="#808080" cursor="pointer"/>
                )
              }
              style={{ height: 45 }}
            />
          </Form.Item>}

          <Button
            type="primary"
            size="large"
            style={{ width: "100%", height: 45 }}
          >
            Add Admin
          </Button>
        </Form>
      </Modal>
    </>
  );
};

export default AddAdminModal;
