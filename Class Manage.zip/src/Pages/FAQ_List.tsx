import {
    EditOutlined
} from "@ant-design/icons";
import { Button, Space, Table, Tooltip } from "antd";
import dayjs from "dayjs";
import { TfiTrash } from "react-icons/tfi";
import AddAdminModal from "./AddAdminModal";
import { useState } from "react";

const FAQ_List = () => {
      const [isModalOpen, setIsModalOpen] = useState(false);

  const columns = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },

    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Role",
      dataIndex: "role",
      key: "role",
    },
    {
      title: "Created AT",
      dataIndex: "joinDate",
      key: "joinDate",
      render: (joinDate: string) => dayjs(joinDate).format("MMMM D, YYYY"),
    },
    {
      title: "Last Login",
      dataIndex: "lastLogin",
      key: "lastLogin",
      render: (lastLogin: string) => (
        <span>{new Date(lastLogin).toLocaleDateString()}</span>
      ),
    },
    {
      title: "Actions",
      key: "actions",
      render: (_: any, record: any) => (
        <Space size="middle">
          <Tooltip title="Edit">
            <EditOutlined
              size={20}
              style={{ color: "orange", cursor: "pointer" }}
              onClick={() => console.log("Edit:", record)}
            />
          </Tooltip>

          <Tooltip title="Delete">
            <TfiTrash
              size={20}
              style={{ color: "red", cursor: "pointer" }}
              onClick={() => console.log("Delete:", record)}
            />
          </Tooltip>
        </Space>
      ),
    },
  ];

//   ------------------- Action -----------------
  const handleAdd = (data:any) => {
    console.log("Added:", data);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">        
            <h1 className="text-2xl text-white font-semibold">Admin</h1>
          <Button
          onClick={()=>setIsModalOpen(true)}
            type="primary"            
            size="large"
            style={{
              width: 150,
              height: 50,
              borderRadius: 20,
              background: "rgba(255, 255, 255, 0.1)",
              marginTop: 20,
            }}
          >
            Add Admin
          </Button>        
      </div>
      <Table
        dataSource={dataSource}
        columns={columns}
        bordered
        pagination={{ pageSize: 10 }}
      />;
           <AddAdminModal open={isModalOpen} setOpen={setIsModalOpen} mode="add" onSubmit={handleAdd} />
    </div>
  );
};

export default FAQ_List;

const dataSource = [
  {
    key: 1,
    name: "John Smith",
    status: "Active",
    email: "john.smith@example.com",
    role: "Admin",
    joinDate: "2024-01-15",
    lastLogin: "2024-07-10",
  },
  {
    key: 2,
    name: "Emma Johnson",
    status: "Banned",
    email: "emma.johnson@example.com",
    role: "User",
    joinDate: "2023-11-22",
    lastLogin: "2023-11-25",
  },
  {
    key: 3,
    name: "Liam Brown",
    status: "Active",
    email: "liam.brown@example.com",
    role: "User",
    joinDate: "2024-03-09",
    lastLogin: "2024-07-01",
  },
  {
    key: 4,
    name: "Olivia Davis",
    status: "Active",
    email: "olivia.davis@example.com",
    role: "Editor",
    joinDate: "2024-05-01",
    lastLogin: "2024-06-29",
  },
  {
    key: 5,
    name: "Noah Wilson",
    status: "Banned",
    email: "noah.wilson@example.com",
    role: "User",
    joinDate: "2023-12-17",
    lastLogin: "2023-12-20",
  },
  {
    key: 6,
    name: "Ava Martinez",
    status: "Active",
    email: "ava.martinez@example.com",
    role: "Admin",
    joinDate: "2024-07-20",
    lastLogin: "2024-07-21",
  },
  {
    key: 7,
    name: "Ethan Anderson",
    status: "Banned",
    email: "ethan.anderson@example.com",
    role: "User",
    joinDate: "2023-09-05",
    lastLogin: "2023-09-15",
  },
  {
    key: 8,
    name: "Sophia Thomas",
    status: "Active",
    email: "sophia.thomas@example.com",
    role: "Editor",
    joinDate: "2024-02-12",
    lastLogin: "2024-07-05",
  },
  {
    key: 9,
    name: "Mason Taylor",
    status: "Active",
    email: "mason.taylor@example.com",
    role: "User",
    joinDate: "2024-04-28",
    lastLogin: "2024-06-10",
  },
  {
    key: 10,
    name: "Isabella Moore",
    status: "Banned",
    email: "isabella.moore@example.com",
    role: "Admin",
    joinDate: "2023-08-30",
    lastLogin: "2023-09-01",
  },
];
