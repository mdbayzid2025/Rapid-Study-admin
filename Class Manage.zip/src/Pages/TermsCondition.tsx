import { Button } from "antd";
import JoditEditor from "jodit-react";
import { useRef, useState } from "react";
import toast from "react-hot-toast";
import { initialContent } from "./PrivacyPolicy";

const TermsCondition = () => {
  const editor = useRef(null);
    const [content, setContent] = useState(initialContent || "");
  const [showEditor, setShowEditor] = useState(false);

  const handleSubmit = async () => {
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = content;
    const plainText = tempDiv.innerText.trim();

    if (!plainText) {
      toast.error("Content cannot be empty");
      return;
    }

    try {
      toast.success("Saved successfully");
      // refetch();
    } catch (err) {
      console.error("Error saving:", err);
      toast.error("Failed to save content");
    }
  };

  const config = {
    readonly: false,
    placeholder: "Start typing...",
    style: {
      height: "50vh",
      background: "white",
    },
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl text-white font-semibold">
          Terms & Conditions{" "}
        </h1>
        <Button
          onClick={() => setShowEditor(!showEditor)}
          type="primary"
          size="large"
          style={{
            width: 150,
            height: 50,
            borderRadius: 20,
            background: "rgba(255, 255, 255, 0.1)",
            marginTop: 20,
          }}
        >
          Edit
        </Button>
      </div>

      {/* -------------- Editor ---------------- */}

      {showEditor ? (
        <div className="">
        <JoditEditor
          ref={editor}
          value={content}
          config={config}
          tabIndex={1} // tabIndex of textarea
          onBlur={(newContent) => setContent(newContent)}
        />
        <div className="flex items-center justify-end gap-4">
           <Button
          onClick={() => setShowEditor(!showEditor)}
          type="primary"
          size="large"
          style={{
            width: 150,
            height: 50,
            borderRadius: 20,
            border: "1px solid #989898",
            background: "transparent",
            marginTop: 20,
          }}
        >
          Cancel
        </Button>
         <Button
          onClick={() => setShowEditor(!showEditor)}
          type="primary"
          size="large"
          style={{
            width: 150,
            height: 50,
            borderRadius: 20,
            background: "rgba(255, 255, 255, 0.1)",
            marginTop: 20,
          }}
        >
          Update
        </Button>
        </div>
        </div>
      ) : (
        <div>
          <div
            style={{
              border: "1px solid #989898",
              borderRadius: 20,
              padding: "20px",
              minHeight: "600px",
              maxHeight: "600px",            
              marginTop: "20px",
              color: "#A1A1A1",
              overflow: "auto",
              background: 'transparent'
            }}
            dangerouslySetInnerHTML={{ __html: content || "No content yet." }}
          />
        </div>
      )}
      
    </div>
  );
};

export default TermsCondition;
