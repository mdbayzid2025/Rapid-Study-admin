import React from "react";
import { Button, ConfigProvider, Form, Input } from "antd";
import { MdOutlineVisibility, MdOutlineVisibilityOff } from "react-icons/md";

const Setting: React.FC = () => {
  const [form] = Form.useForm();

  const handleSubmit = async (values: { currentPassword: string; newPassword: string; confirmPassword: string }) => {
    try {
      console.log("handleSubmit", values);
      // TODO: call your API here
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: "#002C66",
          colorBgContainer: "#F1F4F9",
        },
        components: {
          Input: {
            borderRadius: 12,
            colorBorder: "#989898",
            colorText: "#757575",
            inputFontSize: 16,
            colorTextPlaceholder: "#808080",
          },
          Checkbox: {
            colorBgContainer: "transparent",
            colorBorder: "#989898",
            colorText: "#989898",
            fontSize: 15,
            colorPrimary: "#989898",
            colorPrimaryHover: "#989898",
            controlInteractiveSize: 20,
            borderRadiusSM: 50,
          },
        },
      }}
    >
      <div>
        <div className="mb-6">
          <h1 className="text-2xl text-white font-semibold">Change Password</h1>
        </div>

        <div className="max-w-lg border border-borderColor px-4 py-6 rounded-2xl">
          <Form form={form} layout="vertical" onFinish={handleSubmit} autoComplete="off">
            <Form.Item
              name="currentPassword"
              label={<p className="text-white font-semibold text-lg">Current Password</p>}
              rules={[
                { required: true, message: "Please enter your current password" },
                { min: 6, message: "Password must be at least 6 characters" },
              ]}
              hasFeedback
            >
              <Input.Password
                style={{ backgroundColor: "#00000040", height: 48 }}
                placeholder="Current Password"
                iconRender={(visible) =>
                  visible ? (
                    <MdOutlineVisibility size={20} color="#808080" />
                  ) : (
                    <MdOutlineVisibilityOff size={20} color="#808080" />
                  )
                }
              />
            </Form.Item>

            <Form.Item
              name="newPassword"
              label={<p className="text-white font-semibold text-lg">New Password</p>}
              rules={[
                { required: true, message: "Please enter your new password" },
                { min: 6, message: "Password must be at least 6 characters" },
              ]}
              hasFeedback
            >
              <Input.Password
                style={{ backgroundColor: "#00000040", height: 48 }}
                placeholder="New Password"
                iconRender={(visible) =>
                  visible ? (
                    <MdOutlineVisibility size={20} color="#808080" />
                  ) : (
                    <MdOutlineVisibilityOff size={20} color="#808080" />
                  )
                }
              />
            </Form.Item>

            <Form.Item
              name="confirmPassword"
              label={<p className="text-white font-semibold text-lg">Confirm Password</p>}
              dependencies={["newPassword"]}
              hasFeedback
              rules={[
                { required: true, message: "Please confirm your new password" },
                ({ getFieldValue }) => ({
                  validator(_, value) {
                    if (!value || getFieldValue("newPassword") === value) {
                      return Promise.resolve();
                    }
                    return Promise.reject(new Error("Passwords do not match"));
                  },
                }),
              ]}
            >
              <Input.Password
                style={{ backgroundColor: "#00000040", height: 48 }}
                placeholder="Confirm Password"
                iconRender={(visible) =>
                  visible ? (
                    <MdOutlineVisibility size={20} color="#808080" />
                  ) : (
                    <MdOutlineVisibilityOff size={20} color="#808080" />
                  )
                }
              />
            </Form.Item>

            <Button
              type="primary"
              htmlType="submit"
              size="large"
              style={{
                width: "100%",
                height: 50,
                borderRadius: 20,
                background: "rgba(255, 255, 255, 0.1)",
                marginTop: 20,
              }}
            >
              Update
            </Button>
          </Form>
        </div>
      </div>
    </ConfigProvider>
  );
};

export default Setting;
