import React from "react";
import { Button, ConfigProvider, Select } from "antd";
import { Bar, BarChart, CartesianGrid, Legend, Rectangle, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

const { Option } = Select;

const UserActivityCharts = () => {

const CustomTooltip = ({ active, payload, label, coordinate }: any) => {
  const isVisible = active && payload && payload.length;
  const tooltipHeight = 40; // Height of your tooltip (you may need to adjust this)
  const chartHeight = 400; // Height of the chart (adjust based on your actual chart height)
  
  // Calculate vertical position to center the tooltip
  const tooltipY = coordinate ? coordinate.y - tooltipHeight / 2 : 0;
console.log("payload", payload);

  return (
    <div 
      className="top-20 mr-10" 
      style={{ 
        visibility: isVisible ? 'visible' : 'hidden',
        position: 'absolute', 
        left: coordinate ? coordinate.x + 10 : 0,  // Center horizontally
        top: tooltipY,  // Center vertically relative to the chart
        transform: 'translateY(0)',  // Ensure no additional vertical offset
      }}
    >
      {isVisible && (
        <div className="p-2 rounded-md bg-[#808080] text-white">
          <p className="label  font-semibold text-sm whitespace-nowrap">{`New : ${payload[0]?.value}`}</p>
          <p className="label  font-semibold text-sm whitespace-nowrap">{`${payload[1]?.name} : ${payload[0].value}`}</p>
            <span></span> 
        </div>
      )}
    </div>
  );
};
  return (
    <div className="w-full pb-5 pt-10 bg-black rounded-xl mt-6">
      <div className="flex items-center justify-between px-6">
        <p className="tfont-bold text-white text-2xl">
          User Growth and Deactivation
        </p>

        <ConfigProvider
          theme={{
            components: {
              Select: {
                colorBgContainer: "rgba(255, 255, 255, 0.1)",
                colorBorder: "#808080",
                colorText: "#FFFFFF",
                colorBgElevated: "#808080",
                optionSelectedBg: "#121212",
                optionActiveBg: "#404040",                
              },
            },
          }}
        >
          <Select
            defaultValue="2025"
            style={{
              width: 120,
              textAlign: "start",
              backgroundColor: "transparent",
            }}
          >
            <Option value="2025">
              2025
            </Option>
            <Option value="2026">
              2026
            </Option>
            <Option value="2027">
              2027
            </Option>
            <Option value="2028">
              2028
            </Option>
          </Select>
        </ConfigProvider>
      </div>

      <div className="mt-6">
        <ResponsiveContainer width="100%" height={400}>
          <BarChart
            data={userChartData}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid vertical={false}  strokeDasharray={1}/>
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip position={{ y: -10 }}  content={CustomTooltip}/>
            <Legend />
            <Bar
              barSize={25}
            //   radius={50}
              dataKey="Total"
              // fill="#A1A1A1"              
              fill="#dddddd"              
            />
            <Bar
              barSize={25}
            //   radius={50}
              dataKey="Active"
              fill="#404040"                                 
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default UserActivityCharts;

export const userChartData = [
  { month: "Jan", Total: 1200, Active: 2220 },
  { month: "Feb", Total: 1500, Active: 1100 },
  { month: "Mar", Total: 1700, Active: 1250 },
  { month: "Apr", Total: 1600, Active: 1180 },
  { month: "May", Total: 1900, Active: 1400 },
  { month: "Jun", Total: 2100, Active: 1550 },
  { month: "Jul", Total: 2300, Active: 1650 },
  { month: "Aug", Total: 2500, Active: 1800 },
  { month: "Sep", Total: 2700, Active: 1900 },
  { month: "Oct", Total: 2900, Active: 1250 },
  { month: "Nov", Total: 3100, Active: 900 },
  { month: "Dec", Total: 3500, Active: 2600 },
];
