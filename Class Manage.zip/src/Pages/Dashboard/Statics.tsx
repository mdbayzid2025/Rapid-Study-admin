import React from 'react'
import { FiUserMinus } from 'react-icons/fi'
import { HiOutlineUserGroup } from 'react-icons/hi'
import { LiaUserCheckSolid } from 'react-icons/lia'

const Statics = () => {
  return (
    <div className='flex items-center gap-10 justify-between'>
        {stataicsData && stataicsData?.map(item=>
            <div className="flex items-center gap-5 bg-black w-full p-5 rounded-2xl">   
            <div className=" bg-gray w-24 flex items-center justify-center py-5 rounded-full">
                {item?.icon}
            </div>
            <div className="">
                <p className='text-xl text-white font-normal'>{item?.title}</p>
                <h1 className='font-semibold text-white text-5xl'>{item?.total}</h1>
            </div>

            </div>
        )}
    </div>
  )
}

export default Statics

const stataicsData = [
    {
        title: "Total User",
        total: 5000,
        icon: <HiOutlineUserGroup size={50} color='white'/>,
    },
    {
        title: "Total Active User",
        total: 3000,
        icon: <LiaUserCheckSolid size={50} color='white'/>,
    },
    {
        title: "Total Deactive User",
        total: 5000,
        icon: <FiUserMinus size={50} color='white'/>,
    },
]