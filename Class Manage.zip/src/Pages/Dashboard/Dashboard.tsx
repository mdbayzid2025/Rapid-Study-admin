import React from 'react'
import Statics from './Statics'
import UserActivityCharts from './UserActivityCharts'

const Dashboard = () => {
  return (
    <div className='h-full'>
      <Statics/>
      <UserActivityCharts/>
    </div>
  )
}

export default Dashboard